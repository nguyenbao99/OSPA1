#include <linux/kernel.h>
#include <linux/linkage.h>
#include <linux/uaccess.h>

asmlinkage long sys_cs3753_add(int num1,int num2,int *result)
{
	int sum = 0;
	printk(KERN_ALERT "num1 value is %d\n", num1);
	printk(KERN_ALERT "num2 value is %d\n", num2);
	sum = num1 + num2;
	printk(KERN_ALERT "sum value is %d\n", sum);
	return put_user(sum,result);
} 
