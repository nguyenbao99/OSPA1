#include <stdio.h>
#include <linux/kernel.h>
#include <sys/syscall.h>
#include <unistd.h>
int main()
{
	int sum = 0;
	int check = syscall(334,2,3,&sum);
	printf("Check: %d\n", check);
	printf("Sum of 2 and 3 is: %d\n", sum);
	return 0;		
}
